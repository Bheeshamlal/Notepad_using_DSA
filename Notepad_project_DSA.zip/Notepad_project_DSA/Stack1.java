import java.util.List;
import java.util.ArrayList;

public class Stack1
{
     ArrayList<String> list=new ArrayList<String>();
    
        
        int i = 0;
        int index = -1;
        public void push(String data) { 
            list.add(data);
            index = list.size();
            System.out.println(index+"1");
        }
    
        public String pop() {
        
        if(index > -1){
            
        
          return list.get(--index);
        }
          else
          {
              return null;
          }
          
        }
        public boolean isEmpty() {
            
            if(list.size()==-1)
            return false;
            else
            {
                return true;
            }
            
            
            
          }
        public String pop1() {
            
            if((index < list.size() - 1) )
            return list.get(index++);
            else
            {
                return null;
            }
            
            
            
          }
        public void display() {
    
            System.out.print(list);
    
        }
    
    }
    
    