 class Node {
	
	int data;
	Node next;
	
	Node (int data)
	{
		this.data = data;
		next = null;
	}
}

 class LinkedList2 {

	Node head;
	
	public void AddAtBeginning(int data)
	{		
		if (head == null) head = new Node (data);
		
		else {
			Node newPerson = new Node(data);
			newPerson.next = head;
			head = newPerson;
		}	
	}
	
	public void AddAtEnd(int data)
	{		
		if (head == null) head = new Node (data);
		
		else {
			
			Node curPerson = head;
			while (curPerson.next != null) curPerson = curPerson.next;
			curPerson.next = new Node(data);
		}	
	}
	
	public void printAllData()
	{	
		Node cur = head;
		while (cur.next != null) {
			System.out.print(cur.data + ", ");
			cur = cur.next;
		}
		System.out.print(cur.data);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LinkedList2 list1 = new LinkedList2();
		list1.AddAtBeginning(10);
		list1.AddAtBeginning(20);
		list1.AddAtEnd(30);
		list1.AddAtBeginning(40);
		list1.AddAtEnd(50);
		list1.AddAtBeginning(60);
		list1.AddAtEnd(70);
		list1.AddAtEnd(80);
		
		list1.printAllData();

	}

}