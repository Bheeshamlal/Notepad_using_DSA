import java.util.*;
class Node
{
	int data;
	Node next;

	Node (int data)
	{
		this.data = data;
		this.next = null;
	}
}
class LinkedList
{
	public void addAtEnd(int data)
	{
		Node head;
		Node newNode = new Node(data);
		if (head == null)
		{
			 head = newNode;
		}
		else
		{
			while(head.next != null)
			{
				newNode.next = head;
				newNode = head;
			}
			//head.next = newNode;
		}
		public void show()
		{
			Node head;
			Node newNode = newNode(data);
			if (head == null)
			{
				head = newNode;
			}
			else
			{
				while(head.next!=null)
				{
					System.out.print(head.data + ", ");
					head.next = newNode;
				}
			}
		}
	}
	public static void main(String[] args)
	{
		LinkedList list = new LinkedList();
		list.addAtEnd(1);
		list.addAtEnd(2);
		list.addAtEnd(3);
	
		list.show();
	}
}





